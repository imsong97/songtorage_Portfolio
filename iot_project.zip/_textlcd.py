import RPi.GPIO as GPIO
from time import sleep

try:
    import aiy.device.Adafruit.CharLCD as LCD
except ImportError:
    import Adafruit_CharLCD as LCD


# Raspberry Pi pin setup
LCD_RS = 22
#LCD_RW = GND(23)
LCD_RW = 23
LCD_E = 24
LCD_D4 = 19
LCD_D5 = 20
LCD_D6 = 26
LCD_D7 = 21

# Define LCD column and row size for 16x2 LCD.
lcd_columns = 16
lcd_rows = 2

lcd = LCD.Adafruit_CharLCD(LCD_RS, LCD_E, LCD_D4, LCD_D5, LCD_D6, LCD_D7, lcd_columns, lcd_rows)

def initTextlcd():
    GPIO.setup(LCD_RW, GPIO.OUT, initial=False)
    GPIO.setup(LCD_RS, GPIO.OUT, initial=False)
    GPIO.setup(LCD_E, GPIO.OUT, initial=False)
    GPIO.setup(LCD_D4, GPIO.OUT, initial=False)
    GPIO.setup(LCD_D5, GPIO.OUT, initial=False)
    GPIO.setup(LCD_D6, GPIO.OUT, initial=False)
    GPIO.setup(LCD_D7, GPIO.OUT, initial=False)
#    GPIO.output(LCD_RW, GPIO.LOW)
#    GPIO.output(LCD_RS, GPIO.HIGH)
#    GPIO.output(LCD_E, GPIO.HIGH)
#    GPIO.output(LCD_D4, GPIO.HIGH)
#    GPIO.output(LCD_D5, GPIO.HIGH)
#    GPIO.output(LCD_D6, GPIO.HIGH)
#    GPIO.output(LCD_D7, GPIO.HIGH)
    lcd.clear()
    lcd.home()
    lcd.show_cursor(True)
    lcd.set_cursor(0,0)
    lcd.blink(True)
#    lcd.message('Hello\nworld!')
    sleep(1.0)      # Wait 1 seconds

def controlLine(line):
    lcd.set_cursor(0, line)

def displayText(text=''):
    lcd.clear()
    lcd.set_cursor(0, 0)
    lcd.message(text[:16])
    lcd.set_cursor(0, 1)
    lcd.message(text[16:])

def controlTextlcd(column, line):
    text = raw_input("Type Something to be displayed on the 1st line: ")
    lcd.clear()
    lcd.set_cursor(column, line)
    lcd.message(text)
    text = raw_input("Type Something to be displayed on the 2nd line: ")
    lcd.set_cursor(column, line+1)
    lcd.message(text)

#    lcd.move_right()    # move entire display
#    sleep(2.0)
#    lcd.move_left()
#    sleep(2.0)

def clearTextlcd():
    lcd.clear()
    lcd.message('clear LCD\nGoodbye!')
#    lcd.message('Goodbye\nWorld!')
    sleep(2.0)
    lcd.clear()
    lcd.show_cursor(False)
    lcd.blink(False)

def main():
#    GPIO.setmode(GPIO.BCM)
    initTextlcd()
    print("start textlcd program ...")

    try:
        while True:
            controlTextlcd(0, 0)
#            displayText('start LCD')
            sleep(0.5)

    except KeyboardInterrupt:
        clearTextlcd()
 #       GPIO.cleanup()


if __name__ == '__main__':
    main()
