#!/usr/bin/env python3

import RPi.GPIO as GPIO
from time import sleep
import aiy.device._textlcd as TLCD #텍스트
import aiy.device._led as LED #led
import aiy.device._keypad as KEY #키패드
import aiy.device._dht11 as DHT #온도,습도
import aiy.device._adc as ADC #가스
import aiy.device._fan as FAN #팬
import aiy.device._buzzer as BUZZER #부저
import aiy.device._pir as PIR #동작감지
import threading

melodyList_m=[4]
noteDurations_m=[1]

melodyList=[5]
noteDurations=[0.5]

def check():
    timer=threading.Timer(3,check)
    
    t=threading.Thread(target=KEY.threadReadKeypad, args=())
    t.daemon=True
    t.start()

    t=DHT.readTemp()
    h=DHT.readHumi()
    g = ADC.readSensor(ADC.GAS_CHANNEL)
    move=PIR.readPir(True)
    
    print(t)
    print(h)
    print(g)

    timer.start()

    if move==1:
        LED.controlLed(LED.LED_3, LED.ON)
        for a in range(1,4):
            BUZZER.playBuzzer(melodyList_m, noteDurations_m)
            sleep(0.1)
    elif move==0:
        LED.controlLed(LED.LED_3, LED.OFF)        

    speech=KEY.keyData

    if speech==1:
        TLCD.displayText("temp: %d" % t)
        if t>20:
            LED.controlLed(LED.LED_1, LED.ON)
            FAN.controlFan(FAN.ON)
            for i in range(1,4):
                BUZZER.playBuzzer(melodyList, noteDurations)
                sleep(0.2)
        else:
            LED.controlLed(LED.LED_1, LED.OFF)
            FAN.controlFan(FAN.OFF)
    elif speech==2:
        TLCD.displayText("humi: %d" % h)
        if h>30:
            LED.controlLed(LED.LED_2, LED.ON)
            for i in range(1,4):
                BUZZER.playBuzzer(melodyList, noteDurations)
                sleep(0.2)
        else:
           LED.controlLed(LED.LED_2, LED.OFF) 
    elif speech==3:
        TLCD.displayText("gas: %d" % g)
        if g>3000:
            FAN.controlFan(FAN.ON)
            LED.controlLed(LED.LED_4, LED.ON)
            for i in range(1,4):
                BUZZER.playBuzzer(melodyList, noteDurations)
                sleep(0.2)
        else:
            FAN.controlFan(FAN.OFF)
            LED.controlLed(LED.LED_4, LED.OFF) 


def main():
    GPIO.setmode(GPIO.BCM)
    # GPIO.setwarnings(False)
    KEY.initKeypad()
    TLCD.initTextlcd()
    ADC.initMcp3208()
    GPIO.setup(DHT.DHT_PIN, GPIO.IN)
    GPIO.setup(BUZZER.BUZZER_PIN, GPIO.OUT)
    pwm = GPIO.PWM(BUZZER.BUZZER_PIN, 100)  

    LED.initLed(LED.LED_1)
    LED.initLed(LED.LED_2)
    LED.initLed(LED.LED_3)
    LED.initLed(LED.LED_4)
    FAN.initFan(FAN.FAN_PIN1, FAN.FAN_PIN2)
          
    print("yes, listening")
    a=input()
    if a=='check':
        check()                     

if __name__ == '__main__':
    main()