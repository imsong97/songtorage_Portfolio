import RPi.GPIO as GPIO
from time import sleep
#import queue
import GPIO_EX

# Raspberry Pi expander pin setup
PIR_PIN = 7
pirState = 0
ON = 1
OFF = 0
#BUF_SIZE = 10
#q = queue.Queue(BUF_SIZE)

'''
def readPir():
    global pirState
    while True:
        input_state = GPIO.input(PIR_PIN)
#        print(input_state)
#        print(pirState)
        if input_state == True:
            if pirState == 0:
                print("Motion Detected.")
            pirState = 1
        else:
            if pirState == 1:
                print("Motion Ended.")
            pirState = 0
        sleep(1)

'''

#def readPir(detect_state, q):
def readPir(detect_state):
    global pirState
#    detect_state = q
#    detect_state = q.get()
#    print(detect_state)
    while detect_state:
#        input_state = GPIO.input(PIR_PIN)
        input_state = GPIO_EX.input(PIR_PIN)

#        print("input : %d"%input_state)
        if input_state == True:
            if pirState == 0:
                print("Motion Detected.")
#                q.put(1)
            pirState = 1
            return 1
        else:
            if pirState == 1:
                print("Motion Ended.")
#                q.put(0)
            pirState = 0
            return 0

def threadReadPir():
    while True:
        readPir(ON)


def main():
    GPIO.setmode(GPIO.BCM)
    GPIO_EX.setup(PIR_PIN, GPIO_EX.IN)

#    initDht11()
    print("start pir program ...")

    try:
        while True:
            readPir(ON)
            sleep(0.5)
            
    except KeyboardInterrupt:
       GPIO.cleanup()

if __name__ == '__main__':
    main()
